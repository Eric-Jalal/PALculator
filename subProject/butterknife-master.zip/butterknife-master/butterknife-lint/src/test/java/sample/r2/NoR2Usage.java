package sample.r2;

public class NoR2Usage { }
